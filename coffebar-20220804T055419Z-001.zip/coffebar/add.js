
var models =[

    {
        name: "Americano ",
        image: 'img/americano.jpg'
    
    },
    {
        name: "Cappucino ",
        image: 'img/cappuccino.jpg'
    
    },
    {
        name: "Espresso ",
        image: 'img/espresso.jpg'
    
    },
    {
        name: "Latte",
        image: 'img/latte.jpg'
    
    },
    {
        name: "Macchiato ",
        image: 'img/macchiato.jpg'
    
    },
    {
        name: "Ristretto",
        image: 'img/ristretto.jpg'
    
    },
    
    
    ];

var index =0;

var slaytCount= models.length;
document.querySelector('.fa-arrow-left').addEventListener('click' ,function(){
    index--;
    showSlide(index);
    console.log(index);
});
document.querySelector('.fa-arrow-right').addEventListener('click' ,function(){
    index++;
    showSlide(index);
    console.log(index);
});

function showSlide(i){
    index=i;
    if (i<0){
        index=slaytCount-1;
    }
    if(i>=slaytCount) {
        index=0
    }

    document.querySelector('.card-title').textContent=models[index].name;
    document.querySelector('.img-top').setAttribute('src' , models[index].image);
   
}
   
